const FORMATS = {
  square: ["1:1", "1024x1024", "square social post, product tile, logo or object render"],
  social: ["4:5", "1024x1280", "premium Instagram feed poster or paid social campaign"],
  portrait: ["2:3", "1024x1536", "portrait editorial, magazine cover or character poster"],
  mobile: ["9:16", "1024x1824", "Reels, Stories, TikTok or mobile-first cover"],
  landscape: ["16:9", "1536x864", "website hero, presentation cover or YouTube banner"],
  ultrawide: ["3:1", "2304x768", "ultrawide campaign hero or seamless triptych"]
};

const ROUTES = {
  "global-hero": {
    en: ["Global Campaign Hero", "a hero subject collides with monumental typography while a larger product or visual echo creates global-campaign scale", "Build a clean studio or brand world around one emotional hero occupying roughly two thirds of the frame. Put one oversized word behind the subject and let the body, product or controlled effects interrupt the letters.", "Use restrained micro-UI: brand, one campaign pill, one feature label and an optional CTA.", "Use one controlled diagonal or radial energy path."],
    pt: ["Campanha Global", "um sujeito herói colide com tipografia monumental enquanto um eco ampliado do produto cria escala de campanha global", "Construa um estúdio limpo ou universo de marca ao redor de um herói que ocupa cerca de dois terços do quadro. Coloque uma palavra gigante atrás do sujeito e deixe corpo, produto ou efeitos interromperem as letras.", "Use micro-UI contido: marca, uma pill de campanha, um benefício e CTA opcional.", "Use uma trajetória diagonal ou radial controlada."]
  },
  fisheye: {
    en: ["Fisheye Impact", "the camera sits inside or impossibly close to the subject, turning tactile foreground material into a tunnel around one clear hero", "Place the lens inside a cup, package, helmet, foam tunnel or circular opening when plausible. Let macro texture press against the edges while the hero pushes toward the viewer through intentional fisheye distortion.", "Curve short type around the opening or protect it in negative space; never create an unreadable ring of letters.", "Direct splash, crumbs or particles outward from the center in one coherent path."],
    pt: ["Impacto Fisheye", "a câmera fica dentro ou colada ao assunto, transformando matéria tátil em um túnel ao redor de um herói claro", "Coloque a lente dentro de copo, embalagem, capacete, espuma ou abertura circular quando plausível. Faça texturas macro pressionarem as bordas enquanto o herói avança com distorção fisheye intencional.", "Curve texto curto ao redor da abertura ou proteja-o em espaço negativo; nunca crie um anel ilegível.", "Direcione respingos, migalhas ou partículas do centro para fora em uma trajetória."]
  },
  geometric: {
    en: ["Geometric Product System", "a real product benefit becomes a geometric vortex where liquid, aroma, ingredients or energy translate into precise vector forms", "Anchor the real product or model-product interaction in the foreground. Grow circles, arcs, planes and thin lines from the product angle, contrasting photoreal surfaces with clean flat geometry.", "Use modern sans-serif type, one oversized campaign word and compact benefit modules aligned to the same grid.", "Use one radial burst or vortex originating at the cap, cup, nozzle or gesture."],
    pt: ["Produto Geométrico", "um benefício real vira vórtice geométrico, traduzindo líquido, aroma, ingredientes ou energia em formas vetoriais", "Ancore o produto real ou interação modelo-produto no primeiro plano. Faça círculos, arcos, planos e linhas nascerem do ângulo do produto, contrastando foto real com geometria flat.", "Use sans moderna, uma palavra gigante e módulos de benefícios alinhados à mesma grade.", "Use explosão radial ou vórtice originado na tampa, copo, bico ou gesto."]
  },
  streetwear: {
    en: ["Streetwear Editorial", "an extreme low-angle, overhead or forced-perspective pose physically interrupts canvas-sized typography", "Choose one decisive camera: ground-level, exact overhead or shoe-first forced perspective. Keep the full styling logic visible and make the body overlap enormous cropped letters.", "Layer huge type with a few hand-touched arrows, non-scannable barcode labels, paper tears and marker strokes.", "Use dust, airflow or one directional graphic trail that reinforces the pose."],
    pt: ["Editorial Streetwear", "uma pose em ângulo extremo, zenital ou perspectiva forçada interrompe tipografia do tamanho do quadro", "Escolha uma câmera decisiva: rente ao chão, zenital exata ou tênis em perspectiva forçada. Mantenha o styling legível e faça o corpo atravessar letras enormes.", "Combine tipografia gigante com poucas setas manuais, códigos não escaneáveis, rasgos e marcador.", "Use poeira, fluxo de ar ou uma trilha gráfica que reforce a pose."]
  },
  collage: {
    en: ["Multi-Frame Editorial Collage", "multiple views of the same subject form one designed system, with every frame serving a distinct narrative or commercial purpose", "Use three, six or eight frames. Assign each one a job: hero portrait, full body, action, product detail, emotional close-up and CTA space. Lock face, outfit, product and lighting continuity.", "Create one title system spanning the composition; selected subjects may cross panel boundaries.", "Build eye flow through gaze, pose progression and one repeated curve or diagonal."],
    pt: ["Colagem Editorial", "múltiplas vistas do mesmo sujeito formam um sistema em que cada quadro cumpre função narrativa ou comercial", "Use três, seis ou oito quadros. Dê função a cada um: retrato, corpo inteiro, ação, detalhe, close emocional e CTA. Trave rosto, roupa, produto e luz.", "Crie um título que atravesse a composição; alguns sujeitos podem cruzar os painéis.", "Construa o fluxo com olhar, progressão de poses e uma curva ou diagonal repetida."]
  },
  infographic: {
    en: ["Knowledge / Map Infographic", "one beautiful central subject becomes a premium reference card surrounded by modular callouts, zoom details and concise facts", "Keep the subject or raised map as hero. Arrange detail windows, routes, labels, ratings and quick facts around it on a strict grid with generous margins.", "Use rounded panels, leader lines, compact icons and short labels; it must feel like a handbook, not an ad or fake dashboard.", "Use routes, arrows and callout paths as the motion system."],
    pt: ["Infográfico / Mapa", "um belo sujeito central vira card de referência cercado por callouts, detalhes ampliados e fatos concisos", "Mantenha o sujeito ou mapa elevado como herói. Organize detalhes, rotas, rótulos e fatos ao redor em grade rígida e margens generosas.", "Use painéis arredondados, linhas-guia, ícones e rótulos curtos; deve parecer manual, não anúncio ou dashboard falso.", "Use rotas, setas e linhas de callout como movimento."]
  },
  zine: {
    en: ["Analog Zine / Notebook", "a physical notebook or rough printed page is overtaken by one halftone image, authentic handwriting and a dominant painted title", "Build the substrate first: ruled paper, spiral binding, folded stock, concrete wall or scanned paper. Paste one high-contrast halftone hero image over it and let selected handwriting cross its edges.", "Mix ballpoint, felt tip, rare red marker and pencil using subject-specific language, real paper grain and ink bleed.", "Create energy with diagonal writing, arrows, crossed-out words and torn edges."],
    pt: ["Zine / Caderno Analógico", "uma página física é tomada por uma imagem em halftone, escrita autêntica e título pintado dominante", "Construa primeiro o suporte: papel pautado, espiral, folha dobrada, concreto ou papel escaneado. Cole uma imagem herói em halftone e deixe parte da escrita atravessar as bordas.", "Misture caneta, feltro, raros traços vermelhos e lápis com linguagem específica, fibra e sangramento de tinta.", "Crie energia com escrita diagonal, setas, palavras riscadas e rasgos."]
  },
  cinematic: {
    en: ["Cinematic Story Sequence", "a controlled sequence escalates from setup to consequence through distinct shots sharing one world, identity and camera language", "Choose three, six or eight numbered panels. Give each one a shot type, action and purpose: establish, approach, trigger, escalation, consequence and final image. Lock geography, wardrobe and direction of movement.", "Keep panel numbers, shot notes and title clean and secondary.", "Make every action cause the next visible reaction with plausible weight and inertia."],
    pt: ["Sequência Cinematográfica", "uma sequência cresce do contexto à consequência em planos que compartilham mundo, identidade e câmera", "Escolha três, seis ou oito painéis. Dê a cada um plano, ação e função: contexto, aproximação, gatilho, escalada, consequência e final. Trave geografia, figurino e direção do movimento.", "Mantenha números, notas e título limpos e secundários.", "Faça cada ação causar a reação seguinte com peso e inércia plausíveis."]
  }
};

const MATCHERS = [
  ["infographic", /\b(infogr[aá]fico|mapa|guia|travel|viagem|enciclop[eé]dia|explicar|specs?)\b/i],
  ["collage", /\b(colagem|collage|triptych|tr[ií]ptico|v[aá]rios frames|multi[- ]?panel|selfies?)\b/i],
  ["cinematic", /\b(storyboard|sequ[eê]ncia|hist[oó]ria|trailer|cinematogr[aá]fic[oa])\b/i],
  ["zine", /\b(zine|caderno|notebook|halftone|risograph|grunge|anos 90|1990)\b/i],
  ["streetwear", /\b(streetwear|y2k|hype|urbano|fashion|moda|t[eê]nis|sneaker|editorial)\b/i],
  ["geometric", /\b(geom[eé]tric|bebida|drink|soda|suco|perfume|skincare|energia|flavor|sabor)\b/i],
  ["fisheye", /\b(fisheye|olho de peixe|dentro d[oa]|macro|viral|perspectiva for[cç]ada)\b/i]
];

const tx = (lang, en, pt) => lang === "pt" ? pt : en;

function detectRoute(idea = "") {
  return MATCHERS.find(([, re]) => re.test(idea))?.[0] || "global-hero";
}

function detectFormat(idea = "", route) {
  if (/\b(3:1|ultrawide|triptych|tr[ií]ptico)\b/i.test(idea)) return "ultrawide";
  if (/\b(16:9|youtube|horizontal|banner|site)\b/i.test(idea)) return "landscape";
  if (/\b(9:16|story|reel|tiktok)\b/i.test(idea)) return "mobile";
  if (/\b(1:1|square|quadrad[oa]|logo|[ií]cone)\b/i.test(idea)) return "square";
  if (/\b(2:3|3:4|magazine|revista|retrato)\b/i.test(idea)) return "portrait";
  return route === "cinematic" ? "landscape" : "social";
}

function resolve(options = {}) {
  const controls = options.artDirection || {};
  const routeId = controls.route && controls.route !== "auto" ? controls.route : detectRoute(options.idea);
  const formatId = controls.format && controls.format !== "auto" ? controls.format : detectFormat(options.idea, routeId);
  const lang = options.outputLang === "pt" ? "pt" : "en";
  const quoted = [...(options.idea || "").matchAll(/["“”']([^"“”']{1,80})["“”']/g)].map((m) => m[1]).join(" / ");
  return {
    routeId,
    route: ROUTES[routeId] || ROUTES["global-hero"],
    formatId,
    format: FORMATS[formatId] || FORMATS.social,
    lang,
    power: controls.power || "campaign",
    quality: controls.quality && controls.quality !== "auto" ? controls.quality : controls.power === "compact" ? "medium" : "high",
    visibleText: (controls.visibleText || quoted).trim(),
    reference: Boolean(controls.preserveReference) || /\b(refer[eê]ncia|reference|anexo|uploaded|preserv[ae])\b/i.test(options.idea || "")
  };
}

function avoids(d) {
  const common = d.lang === "pt"
    ? ["template barato ou banco de imagens genérico", "hierarquia fraca ou vários heróis", "texto errado ou ilegível", "logo, rótulo ou embalagem deformados", "marca-d'água, assinatura, QR escaneável ou código real", "luz chapada ou material plástico", "baixa resolução ou bordas ruidosas", "produtos ou pessoas duplicados", "dedos extras, punhos quebrados ou braços desconectados", "produto flutuante ou pegada falsa", "pele plástica ou perda de identidade"]
    : ["cheap template or generic stock-ad look", "weak hierarchy or competing heroes", "misspelled or unreadable text", "warped logo, label or packaging", "watermark, signature, scannable QR or real barcode", "flat lighting or plastic material", "low-resolution artifacts or noisy edges", "duplicate products or people", "extra fingers, broken wrists or disconnected arms", "floating product or false grip", "plastic skin or identity drift"];
  const specific = {
    collage: tx(d.lang, "different face, outfit or light in each panel", "rosto, roupa ou luz diferentes em cada painel"),
    infographic: tx(d.lang, "fake facts, wrong geography or misplaced landmarks", "fatos falsos, geografia errada ou marcos fora do lugar"),
    cinematic: tx(d.lang, "confusing order, duplicated panels or inconsistent geography", "ordem confusa, painéis duplicados ou geografia inconsistente"),
    fisheye: tx(d.lang, "broken perspective, duplicated straw or unreadable center", "perspectiva quebrada, canudo duplicado ou centro ilegível"),
    zine: tx(d.lang, "clean digital clipart pretending to be handmade", "clipart digital limpo fingindo ser manual")
  };
  return [...common, specific[d.routeId] || tx(d.lang, "effects hiding the hero", "efeitos escondendo o herói")];
}

function settings(model, d) {
  if (!["gpt-image-2", "dalle", "generic"].includes(model)) return "";
  return `MODEL SETTINGS\nmodel: gpt-image-2\nsize: ${d.format[1]}\nquality: ${d.quality}`;
}

function compact(options, model, d) {
  const r = d.route[d.lang];
  const visible = d.visibleText ? tx(d.lang, `Render exactly "${d.visibleText}".`, `Renderize exatamente "${d.visibleText}".`) : tx(d.lang, "No accidental text.", "Sem texto acidental.");
  if (model === "midjourney") return `${options.idea}, ${r[1]}, ${r[2]}, realistic materials, controlled commercial key and rim light, ${visible} --ar ${d.format[0]} --style raw --stylize 180 --v 7 --no watermark, bad hands, warped product, clutter`;
  if (model === "sd-flux") return `${tx(d.lang, "POSITIVE PROMPT", "PROMPT POSITIVO")}: ${options.idea}. ${r[1]}. ${r[2]} ${r[3]} ${visible}\n\n${tx(d.lang, "NEGATIVE PROMPT", "PROMPT NEGATIVO")}: ${avoids(d).join(", ")}`;
  return [settings(model, d), `OUTPUT: ${d.format[0]}, ${d.format[2]}.`, `CORE IDEA: ${r[1]}.`, `SUBJECT: ${options.idea}.`, `DIRECTION: ${r[2]} ${r[3]} ${r[4]} ${visible}`, `STRICTLY AVOID: ${avoids(d).join(", ")}.`].filter(Boolean).join("\n\n");
}

function premium(options, model, d) {
  const r = d.route[d.lang];
  const en = d.lang !== "pt";
  const visible = d.visibleText ? `"${d.visibleText}"` : (en ? "no invented text" : "nenhum texto inventado");
  return [
    settings(model, d),
    `${en ? "ACT AS" : "ATUE COMO"}:\n${en ? "A senior art director, commercial photographer, typography designer and material stylist." : "Diretor de arte sênior, fotógrafo comercial, designer de tipografia e material stylist."}`,
    `${en ? "OUTPUT" : "SAÍDA"}:\n${d.format[0]}, ${d.format[1]}, for ${d.format[2]}.`,
    `${en ? "CORE IDEA" : "IDEIA CENTRAL"}:\n${r[1]}.`,
    `${en ? "HERO SUBJECT" : "SUJEITO HERÓI"}:\n${options.idea}. ${en ? "Create one unmistakable hero with clear action and a three-second silhouette. If a person holds an object, preserve natural hand, wrist, arm and shoulder continuity with believable grip pressure." : "Crie um herói inequívoco, ação clara e silhueta de três segundos. Se uma pessoa segura algo, preserve continuidade de mão, punho, braço e ombro com pressão crível."}`,
    `${en ? "COMPOSITION AND CAMERA" : "COMPOSIÇÃO E CÂMERA"}:\n${r[2]} ${en ? "Define foreground, midground and background. Use one purposeful lens, angle and crop; keep overlap, scale, shadow and reflection physically consistent." : "Defina primeiro plano, plano médio e fundo. Use lente, ângulo e corte intencionais; mantenha sobreposição, escala, sombra e reflexo coerentes."}`,
    `${en ? "DESIGN / MATERIAL / MOTION" : "DESIGN / MATERIAL / MOVIMENTO"}:\n${r[3]} ${en ? "Typography behaves as architecture, not a pasted caption. Prove realism through skin, fabric, glass, metal, paper, food or packaging surface behavior. " : "Tipografia funciona como arquitetura, não legenda colada. Prove realismo pelo comportamento de pele, tecido, vidro, metal, papel, comida ou embalagem. "}${r[4]}`,
    `${en ? "LIGHTING AND COLOR" : "LUZ E COR"}:\n${en ? "Use a motivated commercial key, controlled fill and rim separation. Assign one dominant color, one contrast, one neutral and one small accent; keep faces and labels readable." : "Use key comercial motivada, fill controlado e recorte. Atribua uma cor dominante, uma de contraste, um neutro e pequeno acento; mantenha rostos e rótulos legíveis."}`,
    `${en ? "VISIBLE TEXT" : "TEXTO VISÍVEL"}:\n${visible}. ${en ? "Render supplied wording exactly; do not translate, paraphrase or invent claims." : "Renderize o texto fornecido exatamente; não traduza, parafraseie ou invente promessas."}`,
    `${en ? "STRICTLY AVOID" : "EVITAR RIGOROSAMENTE"}:\n${avoids(d).join(", ")}.`
  ].filter(Boolean).join("\n\n");
}

function campaign(options, model, d) {
  const r = d.route[d.lang];
  const en = d.lang !== "pt";
  const visible = d.visibleText || (en ? "[NO REQUIRED TEXT PROVIDED]" : "[NENHUM TEXTO OBRIGATÓRIO INFORMADO]");
  const reference = d.reference
    ? tx(d.lang, "Preserve facial structure, skin tone, hair, product silhouette, packaging colors, label geometry and logo placement from each relevant supplied reference. Use style references only for palette, light and graphic mood.", "Preserve estrutura facial, tom de pele, cabelo, silhueta do produto, cores da embalagem, geometria do rótulo e posição do logo em cada referência relevante. Use referência de estilo apenas para paleta, luz e clima gráfico.")
    : tx(d.lang, "Without official assets, use a brand-inspired treatment and readable wordmark; do not claim exact proprietary logo reproduction.", "Sem arquivos oficiais, use tratamento inspirado na marca e wordmark legível; não prometa reprodução exata de logo proprietário.");
  const body = tx(d.lang, "When a person holds or wears an object, hand, wrist, forearm, elbow and shoulder belong visibly to the same body. Fingers wrap naturally with believable grip pressure; nothing floats.", "Quando uma pessoa segura ou veste um objeto, mão, punho, antebraço, cotovelo e ombro pertencem ao mesmo corpo. Dedos envolvem o objeto com pressão crível; nada flutua.");
  const blocks = [
    settings(model, d),
    `${en ? "ACT AS" : "ATUE COMO"}:\n${en ? "A senior campaign creative director, commercial photographer, product stylist, typography designer and platform strategist. Treat this as a real production brief, not an adjective list." : "Diretor criativo sênior, fotógrafo comercial, product stylist, designer de tipografia e estrategista de plataforma. Trate como briefing real, não lista de adjetivos."}`,
    `${en ? "TASK" : "TAREFA"}:\n${en ? `Create a finished ${d.format[0]} ${d.format[2]} using the ${r[0]} route. Communicate the subject and goal within three seconds at thumbnail size.` : `Crie uma peça final ${d.format[0]} para ${d.format[2]} usando a rota ${r[0]}. Comunique assunto e objetivo em três segundos no tamanho de thumbnail.`}`,
    `${en ? "USER INPUT / SOURCE BRIEF" : "ENTRADA DO USUÁRIO / BRIEFING"}:\n"${options.idea}"\n\n${en ? "Infer audience, emotion and commercial or editorial goal. Do not invent facts, partnerships, prices, specifications or geography; use editable placeholders when accuracy is unknown." : "Infira público, emoção e objetivo comercial ou editorial. Não invente fatos, parcerias, preços, especificações ou geografia; use placeholders quando a precisão for desconhecida."}`,
    `${en ? "PHASE 0 — INTELLIGENCE / INPUT DECODING" : "FASE 0 — INTELIGÊNCIA / DECODIFICAÇÃO"}:\n${en ? "Classify the job as product/FMCG, sport, food/beverage, fashion, portrait, collage, storyboard, infographic, map or 3D object. Lock one hero, one promise and one emotional action. Preserve the user's strongest unusual idea." : "Classifique como produto/FMCG, esporte, comida/bebida, moda, retrato, colagem, storyboard, infográfico, mapa ou objeto 3D. Trave um herói, uma promessa e uma ação emocional. Preserve a ideia incomum mais forte."}`,
    `${en ? "AUTONOMOUS DEFAULTS" : "PADRÕES AUTÔNOMOS"}:\n${en ? "When a minor detail is missing, choose the strongest commercially useful default and keep it consistent. Use 35–50mm for commercial realism, 85mm for portraits, macro for tactile product or food detail, low-angle 35mm for sport and sneakers, and fisheye only when distortion is the concept. Use one dominant subject or brand color, one contrast, one neutral and one small accent. Prefer a controlled studio key plus rim light unless the scene motivates another source." : "Quando faltar detalhe menor, escolha o padrão comercialmente mais forte e mantenha consistência. Use 35–50mm para realismo comercial, 85mm para retrato, macro para produto ou comida, 35mm baixo para esporte e tênis e fisheye apenas quando a distorção for o conceito. Use uma cor dominante, uma de contraste, um neutro e pequeno acento. Prefira key de estúdio com recorte, salvo quando a cena motivar outra fonte."}`,
    `${en ? "CORE VISUAL SYSTEM" : "SISTEMA VISUAL CENTRAL"}:\n${r[1]}. ${en ? "Every object, type choice, effect and light cue grows from this hook. Do not introduce a competing concept." : "Todo objeto, escolha tipográfica, efeito e luz nasce desse gancho. Não introduza conceito concorrente."}`,
    `${en ? "OUTPUT / FORMAT LOCK" : "SAÍDA / TRAVA DE FORMATO"}:\n${d.format[0]}, ${d.format[1]}, for ${d.format[2]}. ${en ? "Keep essential faces, products, labels and copy in safe margins. Compose for phone readability first." : "Mantenha rostos, produtos, rótulos e copy essenciais nas margens seguras. Componha primeiro para leitura mobile."}`,
    `${en ? "VISUAL HIERARCHY" : "HIERARQUIA VISUAL"}:\n1. ${en ? "Hero subject/product and physical hook." : "Herói/produto e gancho físico."}\n2. ${en ? "Campaign headline or primary graphic shape." : "Headline ou forma gráfica principal."}\n3. ${en ? "Benefit, atmosphere, label, CTA or narrative detail." : "Benefício, atmosfera, rótulo, CTA ou detalhe narrativo."}\n${en ? "Remove anything that creates a competing first read." : "Remova tudo que crie primeira leitura concorrente."}`,
    `${en ? "HERO SUBJECT / PRODUCT" : "HERÓI / PRODUTO"}:\n${en ? "Translate the brief into one unmistakable hero with clear action, expression and relationship to the promise. Decide whether the person is the emotional hero or the product is the sales hero. If product-led, keep it razor sharp, unwarped, label-forward, realistically scaled and physically supported." : "Traduza o briefing em um herói inequívoco, com ação, expressão e relação clara com a promessa. Decida se a pessoa é herói emocional ou se o produto é herói de venda. Se o produto lidera, mantenha-o nítido, sem deformação, rótulo para câmera, escala realista e apoio físico."}\n\n${body}\n\n${reference}`,
    `${en ? "COMPOSITION AND CAMERA" : "COMPOSIÇÃO E CÂMERA"}:\n${r[2]}\n\n${en ? "Define foreground, midground and background as distinct jobs. Use one coherent lens, camera height, tilt, crop and perspective. Type may sit behind the subject and selected effects may pass in front; shadows and reflections must agree with those layers." : "Defina primeiro plano, plano médio e fundo com funções distintas. Use uma lente, altura, inclinação, corte e perspectiva coerentes. Texto pode ficar atrás do sujeito e efeitos selecionados à frente; sombras e reflexos devem concordar."}`,
    `${en ? "BACKGROUND / ENVIRONMENT" : "FUNDO / AMBIENTE"}:\n${en ? "The background explains category, mood or benefit instead of acting as filler. Use a brighter value behind the hero silhouette, quieter edges and plausible surfaces, horizon, props and atmosphere." : "O fundo explica categoria, clima ou benefício em vez de preencher. Use valor mais claro atrás da silhueta, bordas calmas e superfícies, horizonte, props e atmosfera plausíveis."}`,
    `${en ? "GRAPHIC DESIGN / TYPOGRAPHY" : "DESIGN GRÁFICO / TIPOGRAFIA"}:\n${r[3]}\n\n${en ? "Typography is architecture, never a caption pasted over a photo. Use one hero headline, one optional subtitle, no more than five micro labels and CTA only when useful. Crop, mask or overlap the main word with purpose. Protect exact spelling and contrast." : "Tipografia é arquitetura, nunca legenda colada sobre foto. Use uma headline, subtítulo opcional, no máximo cinco micro-rótulos e CTA quando útil. Corte, masque ou sobreponha a palavra principal com propósito. Proteja grafia e contraste."}`,
    `${en ? "MATERIAL / TEXTURE TRUTH" : "VERDADE DE MATERIAL / TEXTURA"}:\n${en ? "Prove realism: skin pores and fine hair; fabric weave, weight, seams and gravity; glass thickness and refraction; metal specular response; paper fiber and ink bleed; food steam, crumbs, viscosity, bubbles or condensation. Reflections match the environment and contact shadows connect objects to surfaces." : "Prove realismo: poros e pelos; trama, peso, costura e gravidade do tecido; espessura e refração do vidro; resposta do metal; fibra e tinta do papel; vapor, migalha, viscosidade, bolhas ou condensação da comida. Reflexos combinam com o ambiente e sombras conectam objetos."}`,
    `${en ? "MOTION / ENERGY ARCHITECTURE" : "ARQUITETURA DE MOVIMENTO / ENERGIA"}:\n${r[4]} ${en ? "Motion has one origin, one path and one density curve. Particles vary in scale and depth, blur only when physically justified and become sparse near faces, labels and text." : "O movimento tem uma origem, trajetória e curva de densidade. Partículas variam em escala e profundidade, borram apenas com justificativa e rareiam perto de rosto, rótulo e texto."}`,
    `${en ? "LIGHTING" : "ILUMINAÇÃO"}:\n${en ? "Use a motivated commercial key, controlled fill and rim/accent separation without fake glow. Keep cast shadows, eye catchlights, product reflections and background falloff consistent. Labels and faces stay readable; glossy highlights do not clip; black materials retain texture." : "Use key comercial motivada, fill controlado e recorte sem glow falso. Mantenha sombras, catchlights, reflexos e queda do fundo coerentes. Rótulos e rostos ficam legíveis; highlights não estouram; materiais pretos mantêm textura."}`,
    `${en ? "COLOR SYSTEM" : "SISTEMA DE COR"}:\n${en ? "Assign one dominant background/brand color, one hero/product color, one high-contrast type color, one neutral and one small CTA/energy accent. Use related dark hues for shadows and keep skin, food and product colors believable." : "Atribua uma cor dominante de fundo/marca, uma do herói/produto, uma de alto contraste para texto, um neutro e pequeno acento de CTA/energia. Use tons relacionados nas sombras e preserve cores críveis."}`,
    `${en ? "EXACT VISIBLE TEXT" : "TEXTO VISÍVEL EXATO"}:\n${visible}\n\n${d.visibleText ? (en ? "Render only this wording exactly as written. Do not translate, paraphrase or invent claims." : "Renderize somente esse texto exatamente como escrito. Não traduza, parafraseie ou invente promessas.") : (en ? "Prefer no text or editable bracketed placeholders; do not invent a slogan, price or certification." : "Prefira sem texto ou placeholders entre colchetes; não invente slogan, preço ou certificação.")}`,
    `${en ? "MUST RETAIN" : "DEVE PRESERVAR"}:\n- ${en ? "One dominant three-second hook and one hero." : "Um gancho dominante de três segundos e um herói."}\n- ${r[0]} edge-to-edge logic.\n- ${d.format[0]} composition and ${d.format[1]} setting.\n- ${en ? "Plausible anatomy, contact, scale, shadow and reflection." : "Anatomia, contato, escala, sombra e reflexão plausíveis."}\n- ${en ? "Mobile-readable silhouette and headline." : "Silhueta e headline legíveis no celular."}\n- ${reference}`,
    `${en ? "FINAL QUALITY LOCK" : "TRAVA FINAL DE QUALIDADE"}:\n${en ? "Finish as premium commercial photography or editorial design with precise hierarchy, realistic materials, readable type, controlled color and intentional spacing. Quality comes from direction, not empty words such as masterpiece or 8K." : "Finalize como fotografia comercial ou design editorial premium, com hierarquia precisa, materiais reais, texto legível, cor controlada e espaçamento intencional. A qualidade vem da direção, não de palavras vazias."}`,
    `${en ? "STRICTLY AVOID" : "EVITAR RIGOROSAMENTE"}:\n${avoids(d).map((x) => `- ${x}`).join("\n")}`
  ];
  if (d.power === "master") blocks.splice(-2, 0, `${en ? "MASTER ADAPTATION LOGIC" : "LÓGICA MESTRE DE ADAPTAÇÃO"}:
${en ? `Treat this prompt as a reusable visual system, not a one-off description. Keep the selected hook, hierarchy, camera discipline, typography behavior, material truth, motion path, lighting logic, color roles and failure controls stable while adapting the variables below.

PRODUCT / FMCG: make the product the commercial anchor, usually occupying 60–75% of the frame. Preserve container type, cap, silhouette, label geometry, finish and contact shadow. Treat ordinary products like designed launch objects, not catalog inventory. If benefits are needed, express no more than three to five as compact callouts that support rather than surround the hero.

FOOD / BEVERAGE: lead with appetite texture before brand copy. Use steam, ice, condensation, bubbles, sauce viscosity, crumbs, fruit pulp, grains or foam appropriate to the actual item. Floating ingredients must follow the real construction of the food or one continuous flavor path; avoid engineering-diagram separation and uncontrolled mess.

SPORT / FOOTWEAR: choose one performance beat—ready stance, sprint start, frozen stride, celebration or low-angle shoe dominance. Keep the full body and footwear visible when product performance matters. Use sweat, dust, water, wet ground, tunnel light or stadium atmosphere only when motivated by the action. Preserve sole geometry, mesh, stitching and believable foreshortening.

FASHION / STREETWEAR: prioritize model attitude, garment construction and camera extremity. Describe silhouette, weight, layering, fabric, closures and shoe visibility. Let monumental type interact with the body as architecture, then add only a few imperfect hand-touched marks. Never let stickers replace composition.

PORTRAIT / IDENTITY: lock facial structure, eye shape, hairstyle, skin tone, expression family, lens and light before changing wardrobe or scene. Keep natural pores and hair detail. If several frames are required, the same person must remain recognizable in every panel without duplicated poses or beauty-filter plasticity.

COLLAGE / STORYBOARD: define the panel count and purpose before styling. Each panel gets one distinct job, yet face, product, outfit, geography, time of day, light direction and grade remain continuous. Use deliberate gutters, overlaps or seamless edges; avoid a cheap split-screen. For narrative sequences, every action creates the next visible consequence.

INFOGRAPHIC / MAP: keep one beautiful subject or raised terrain map as the visual hero. Facts, callouts, routes, labels and detail windows follow a strict grid and remain concise. Verify geography, landmarks, names and current claims outside the image model. If verification is unavailable, use explicit editable placeholders instead of confident false data.

REFERENCE AND EDIT LOGIC: identify each supplied image by role—identity, product, packaging, outfit, pose, composition or style. Preserve invariant geometry and identity from factual references; borrow only palette, light or mood from style references. For a follow-up edit, change only the requested layer and repeat every invariant that must not drift.

TEXT AND BRAND LOGIC: quote every required visible phrase exactly and specify placement, scale, color and type personality. Keep one headline, one optional subtitle, three to five short labels and a CTA only when needed. Use a supplied official logo asset when available; otherwise use a readable brand-inspired wordmark. Never invent a scannable QR code, real barcode, official certification, current campaign or proprietary logo geometry from memory.

VARIANT LOGIC: to produce additional versions, change only one high-level variable at a time—hook intensity, camera position, palette, model pose, motion path or typography behavior. Preserve subject, product, required text, format, reference identity and commercial objective so the variants belong to one campaign family.` : `Trate este prompt como sistema visual reutilizável, não descrição isolada. Mantenha gancho, hierarquia, câmera, tipografia, materiais, movimento, luz, cor e controles de falha estáveis enquanto adapta as variáveis abaixo.

PRODUTO / FMCG: faça do produto a âncora comercial, ocupando normalmente 60–75% do quadro. Preserve recipiente, tampa, silhueta, geometria do rótulo, acabamento e sombra de contato. Trate produtos comuns como objetos de lançamento, não itens de catálogo. Expresse no máximo três a cinco benefícios em callouts compactos.

COMIDA / BEBIDA: lidere com textura apetitosa antes da copy. Use vapor, gelo, condensação, bolhas, viscosidade, migalhas, polpa, grãos ou espuma adequados. Ingredientes flutuantes seguem a construção real do alimento ou uma única trajetória de sabor; evite diagrama de engenharia e bagunça.

ESPORTE / CALÇADO: escolha um momento — prontidão, largada, passada congelada, celebração ou tênis dominante em ângulo baixo. Mantenha corpo e calçado visíveis quando a performance importa. Use suor, poeira, água, piso molhado, túnel ou estádio somente quando motivados. Preserve solado, mesh, costura e perspectiva crível.

MODA / STREETWEAR: priorize atitude, construção da roupa e câmera extrema. Descreva silhueta, peso, camadas, tecido, fechos e visibilidade do calçado. Faça tipografia monumental interagir com o corpo e use poucas marcas manuais imperfeitas. Adesivos nunca substituem composição.

RETRATO / IDENTIDADE: trave estrutura facial, olhos, cabelo, tom de pele, família de expressão, lente e luz antes de mudar roupa ou cena. Preserve poros e cabelo naturais. Em múltiplos quadros, a mesma pessoa permanece reconhecível sem poses duplicadas ou pele plástica.

COLAGEM / STORYBOARD: defina quantidade e função dos painéis antes do estilo. Cada quadro tem uma tarefa, mas rosto, produto, roupa, geografia, hora, direção da luz e grade permanecem contínuos. Use respiros, sobreposições ou bordas contínuas; evite split-screen barato. Em narrativa, cada ação causa a próxima consequência.

INFOGRÁFICO / MAPA: mantenha um belo sujeito ou terreno elevado como herói. Fatos, callouts, rotas, rótulos e janelas seguem grade rígida e texto conciso. Verifique geografia, marcos, nomes e afirmações atuais fora do modelo. Sem verificação, use placeholders editáveis em vez de dados falsos.

REFERÊNCIAS E EDIÇÃO: identifique cada arquivo por função — identidade, produto, embalagem, roupa, pose, composição ou estilo. Preserve geometria e identidade das referências factuais; use apenas paleta, luz ou clima das referências de estilo. Em edição seguinte, mude somente a camada pedida e repita tudo que não pode sofrer drift.

TEXTO E MARCA: coloque toda frase obrigatória entre aspas e defina posição, escala, cor e personalidade tipográfica. Use uma headline, subtítulo opcional, três a cinco rótulos e CTA quando necessário. Use logo oficial fornecido; sem arquivo, use wordmark inspirado e legível. Nunca invente QR escaneável, código real, certificação, campanha atual ou geometria proprietária.

VARIANTES: para criar novas versões, mude uma variável grande por vez — intensidade do gancho, câmera, paleta, pose, movimento ou tipografia. Preserve sujeito, produto, texto, formato, identidade da referência e objetivo comercial para que todas pertençam à mesma campanha.

CONTROLE FINAL DO SISTEMA: antes de entregar, releia o briefing como diretor criativo, fotógrafo, designer e especialista da plataforma. Remova detalhes que não controlam a imagem, resolva instruções contraditórias, confirme a primeira leitura em três segundos e garanta que o conceito continue forte mesmo sem palavras genéricas de qualidade. Se qualquer camada ainda depender de sorte, torne-a física, espacial e verificável.`}`);
  if (d.power === "master") blocks.splice(-2, 0, `${en ? "12-POINT POWER AUDIT" : "AUDITORIA DE POTÊNCIA EM 12 PONTOS"}:\n${["named hook", "first/second/third reads", "camera logic", "three depth layers", "subject physics", "material truth", "typography behavior", "motion path", "lighting logic", "color roles", "platform fit", "specific failure controls"].map((x, i) => `${i + 1}. ${x}`).join("\n")}\n${en ? "Do not finalize until at least nine checks pass; redesign weak layers instead of adding adjectives." : "Não finalize até nove critérios passarem; redesenhe camadas fracas em vez de adicionar adjetivos."}`);
  return blocks.filter(Boolean).join("\n\n");
}

export function buildArtDirectorPrompt(options, model = "gpt-image-2") {
  const d = resolve(options);
  if (d.power === "compact" || ["midjourney", "sd-flux"].includes(model)) return compact(options, model, d);
  if (d.power === "premium") return premium(options, model, d);
  return campaign(options, model, d);
}

export function getArtDirectionSummary(options = {}) {
  const d = resolve(options);
  return { route: d.route[d.lang][0], ratio: d.format[0], size: d.format[1], power: d.power, quality: d.quality };
}

export function auditArtDirection(prompt = "", options = {}) {
  const d = resolve(options);
  const tests = [
    /CORE VISUAL|SISTEMA VISUAL|CORE IDEA|IDEIA CENTRAL|fisheye|vortex|vórtice/i,
    /VISUAL HIERARCHY|HIERARQUIA VISUAL|First read|Primeira leitura/i,
    /CAMERA|CÂMERA|lens|lente|fisheye|macro/i,
    /foreground|midground|background|primeiro plano|plano médio|fundo/i,
    /grip|contact|anatom|pegada|contato|apoio/i,
    /MATERIAL|TEXTURE|SUPERFÍCIE|fabric|glass|skin|tecido|vidro|pele/i,
    /TYPOGRAPHY|TIPOGRAFIA|headline|wordmark/i,
    /MOTION|MOVIMENTO|ENERGY|ENERGIA|particles|partículas/i,
    /LIGHTING|ILUMINAÇÃO|key|rim|recorte/i,
    /COLOR SYSTEM|SISTEMA DE COR|palette|paleta/i,
    new RegExp(`${d.format[0].replace(":", "\\:")}|${d.format[1]}|Instagram|TikTok|website|mobile`, "i"),
    /STRICTLY AVOID|EVITAR RIGOROSAMENTE|NEGATIVE PROMPT|PROMPT NEGATIVO/i
  ];
  return { score: tests.filter((re) => re.test(prompt)).length, total: tests.length };
}
