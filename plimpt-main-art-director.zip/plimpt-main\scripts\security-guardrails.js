const ALWAYS_SECURE_CATEGORIES = new Set([
  "website",
  "saas",
  "code",
  "debug",
  "product",
  "ux",
  "data",
  "assistant"
]);

const SECURITY_KEYWORDS = [
  "account",
  "admin",
  "api",
  "auth",
  "authorization",
  "backup",
  "bank",
  "billing",
  "checkout",
  "cookie",
  "cors",
  "csrf",
  "dashboard",
  "database",
  "gdpr",
  "lgpd",
  "login",
  "password",
  "payment",
  "permission",
  "pix",
  "private",
  "profile",
  "role",
  "saas",
  "secret",
  "session",
  "signup",
  "sql",
  "subscription",
  "tenant",
  "token",
  "upload",
  "user",
  "webhook",
  "xss",
  "administrador",
  "assinatura",
  "autenticacao",
  "autorizacao",
  "banco",
  "cadastro",
  "cartao",
  "cliente",
  "conta",
  "dados",
  "entrar",
  "login",
  "pagamento",
  "permissao",
  "senha",
  "usuario"
];

const CATEGORY_FOCUS = {
  website: ["forms", "public surface", "tracking consent", "safe CMS/admin access"],
  saas: ["multi-tenant isolation", "RBAC", "billing safety", "audit logs", "data retention"],
  code: ["secure implementation details", "tests", "dependency risk", "runtime configuration"],
  debug: ["minimal safe fix", "regression checks", "error handling", "no secret leakage"],
  product: ["abuse cases", "privacy requirements", "safe acceptance criteria", "operational risk"],
  ux: ["safe flows", "clear error states", "destructive-action confirmation", "accessibility"],
  data: ["data minimization", "PII handling", "access control", "retention"],
  assistant: ["scope boundaries", "sensitive-data handling", "refusal and safe alternatives"]
};

const COPY = {
  en: {
    context: "Security posture: security, privacy, and safe UX are mandatory requirements, not optional extras.",
    task: "While executing the request, explicitly design the result so the user's site, app, SaaS, data, and users are protected by default.",
    core: [
      "Before proposing architecture, code, UX, or a launch plan, identify sensitive data, user roles, trust boundaries, authentication flows, authorization rules, and likely attack surfaces.",
      "Apply secure-by-default choices: authentication, authorization, least privilege, server-side validation, input sanitization, output escaping, safe session/cookie settings, rate limiting, and abuse prevention.",
      "Protect against common web risks when relevant: XSS, CSRF, SQL injection, SSRF, insecure direct object references, unsafe redirects, insecure CORS, weak CSP, brute force, credential stuffing, and insecure file uploads.",
      "Never recommend storing passwords, tokens, API keys, or card data in plain text, source code, browser localStorage for secrets, public repos, logs, screenshots, or client-side bundles.",
      "Use environment variables or a managed secret store for secrets, hash passwords with a modern password hashing algorithm, and avoid exposing stack traces, database errors, tokens, or internal IDs to end users.",
      "Collect the minimum data needed, explain consent/retention/deletion when personal data is involved, and consider LGPD/GDPR-style privacy expectations.",
      "For payments, use a trusted payment provider and tokenized flows; do not store raw card data unless the plan includes proper compliance scope.",
      "If the user asks for an unsafe shortcut, explain the risk briefly and provide the safest practical alternative."
    ],
    saas: [
      "For SaaS, include tenant isolation, RBAC/permissions, audit logs, billing-state handling, backups/restore, account recovery, invite flows, and safe admin operations.",
      "Separate public, authenticated, admin, and background-job surfaces so each has clear permissions and validation."
    ],
    website: [
      "For websites and landing pages, include safe forms, spam protection, consent-aware analytics, HTTPS, CSP, secure headers, accessible error messages, and no exposed admin or secret endpoints."
    ],
    code: [
      "For implementation work, include security tests or verification steps for auth, permissions, validation, error handling, dependency/config risks, and abuse cases."
    ],
    ux: [
      "Improve user experience with loading, empty, error, success, offline/session-expired states, accessible labels, mobile behavior, and confirmation/recovery for destructive actions."
    ],
    output: {
      json: "Because JSON was requested, include explicit keys for security_requirements, privacy_requirements, and ux_safety_checks.",
      default: "Include a final section named \"Security & UX checklist\" with concrete checks the builder must verify before publishing."
    },
    success: [
      "Security and privacy are treated as acceptance criteria, not afterthoughts.",
      "The result names sensitive data, roles, permissions, validation points, and abuse cases when relevant.",
      "The plan avoids unsafe storage of passwords, tokens, API keys, payment data, and personal data.",
      "The final output includes a practical Security & UX checklist."
    ]
  },
  pt: {
    context: "Postura de segurança: segurança, privacidade e UX segura são requisitos obrigatórios, não extras opcionais.",
    task: "Ao executar o pedido, desenhe explicitamente o resultado para proteger por padrão o site, app, SaaS, dados e usuários do cliente.",
    core: [
      "Antes de propor arquitetura, código, UX ou plano de lançamento, identifique dados sensíveis, papéis de usuário, limites de confiança, fluxos de autenticação, regras de autorização e superfícies de ataque prováveis.",
      "Aplique escolhas seguras por padrão: autenticação, autorização, menor privilégio, validação no servidor, sanitização de entrada, escape de saída, sessões/cookies seguros, rate limiting e prevenção de abuso.",
      "Proteja contra riscos comuns da web quando fizer sentido: XSS, CSRF, SQL injection, SSRF, IDOR, redirects inseguros, CORS inseguro, CSP fraca, força bruta, credential stuffing e uploads perigosos.",
      "Nunca recomende guardar senhas, tokens, chaves de API ou dados de cartão em texto puro, código-fonte, localStorage para segredos, repositórios públicos, logs, prints ou bundles do cliente.",
      "Use variáveis de ambiente ou cofre de segredos, hash moderno para senhas, e evite vazar stack trace, erro de banco, token ou IDs internos para usuários finais.",
      "Colete o mínimo de dados necessário, explique consentimento/retenção/exclusão quando houver dados pessoais e considere expectativas de privacidade no estilo LGPD/GDPR.",
      "Para pagamentos, use provedor confiável e fluxo tokenizado; não armazene cartão bruto sem escopo real de conformidade.",
      "Se o usuário pedir um atalho inseguro, explique o risco de forma breve e entregue a alternativa prática mais segura."
    ],
    saas: [
      "Para SaaS, inclua isolamento por tenant/cliente, RBAC/permissões, trilha de auditoria, estado de cobrança, backup/restauração, recuperação de conta, convites e operações admin seguras.",
      "Separe superfícies públicas, autenticadas, administrativas e jobs em segundo plano, cada uma com permissões e validações claras."
    ],
    website: [
      "Para sites e landing pages, inclua formulários seguros, proteção contra spam, analytics com consentimento, HTTPS, CSP, headers seguros, mensagens de erro acessíveis e nenhum endpoint admin/segredo exposto."
    ],
    code: [
      "Para implementação, inclua testes ou verificações de segurança para auth, permissões, validação, erros, dependências/configuração e casos de abuso."
    ],
    ux: [
      "Melhore a experiência com estados de carregamento, vazio, erro, sucesso, offline/sessão expirada, labels acessíveis, comportamento mobile e confirmação/recuperação para ações destrutivas."
    ],
    output: {
      json: "Como JSON foi pedido, inclua chaves explícitas para requisitos_de_seguranca, requisitos_de_privacidade e checklist_ux_segura.",
      default: "Inclua uma seção final chamada \"Checklist de segurança e UX\" com verificações concretas antes de publicar."
    },
    success: [
      "Segurança e privacidade são tratadas como critérios de aceite, não como pós-pensamento.",
      "O resultado nomeia dados sensíveis, papéis, permissões, pontos de validação e casos de abuso quando relevante.",
      "O plano evita armazenamento inseguro de senhas, tokens, chaves de API, dados de pagamento e dados pessoais.",
      "A saída final inclui uma checklist prática de segurança e UX."
    ]
  },
  es: {
    context: "Postura de seguridad: seguridad, privacidad y UX segura son requisitos obligatorios, no extras opcionales.",
    task: "Al ejecutar la solicitud, diseña el resultado para proteger por defecto el sitio, app, SaaS, datos y usuarios del cliente.",
    core: [
      "Antes de proponer arquitectura, código, UX o lanzamiento, identifica datos sensibles, roles, límites de confianza, autenticación, autorización y superficies de ataque.",
      "Aplica opciones seguras por defecto: autenticación, autorización, mínimo privilegio, validación del servidor, sanitización, escape de salida, sesiones/cookies seguros, rate limiting y prevención de abuso.",
      "Protege contra riesgos web comunes cuando aplique: XSS, CSRF, SQL injection, SSRF, IDOR, redirects inseguros, CORS inseguro, CSP débil, fuerza bruta y uploads peligrosos.",
      "No recomiendes guardar contraseñas, tokens, claves API o datos de tarjeta en texto plano, código, localStorage para secretos, repos públicos, logs o bundles del cliente.",
      "Usa variables de entorno o un gestor de secretos, hashing moderno de contraseñas, y no expongas stack traces, errores internos, tokens o IDs internos al usuario final.",
      "Recolecta el mínimo de datos necesario y considera expectativas de privacidad tipo GDPR/LGPD.",
      "Para pagos, usa un proveedor confiable y flujos tokenizados; no almacenes tarjetas en bruto sin cumplimiento real.",
      "Si el usuario pide un atajo inseguro, explica el riesgo brevemente y ofrece la alternativa segura."
    ],
    saas: [
      "Para SaaS, incluye aislamiento por tenant, RBAC/permisos, auditoría, facturación, backups, recuperación de cuenta, invitaciones y operaciones admin seguras.",
      "Separa superficies públicas, autenticadas, administrativas y jobs en segundo plano con permisos y validaciones claras."
    ],
    website: [
      "Para sitios y landing pages, incluye formularios seguros, protección anti-spam, analítica con consentimiento, HTTPS, CSP, headers seguros, errores accesibles y sin endpoints admin/secretos expuestos."
    ],
    code: [
      "Para implementación, incluye pruebas o verificaciones de seguridad para auth, permisos, validación, errores, dependencias/configuración y abuso."
    ],
    ux: [
      "Mejora la experiencia con estados de carga, vacío, error, éxito, offline/sesión expirada, labels accesibles, mobile y confirmación/recuperación para acciones destructivas."
    ],
    output: {
      json: "Como se pidió JSON, incluye claves explícitas para requisitos_de_seguridad, requisitos_de_privacidad y checklist_ux_segura.",
      default: "Incluye una sección final llamada \"Checklist de seguridad y UX\" con verificaciones concretas antes de publicar."
    },
    success: [
      "Seguridad y privacidad son criterios de aceptación, no algo posterior.",
      "El resultado nombra datos sensibles, roles, permisos, validación y casos de abuso cuando corresponde.",
      "El plan evita almacenamiento inseguro de contraseñas, tokens, claves API, pagos y datos personales.",
      "La salida final incluye una checklist práctica de seguridad y UX."
    ]
  }
};

const EMPTY_GUARDRAILS = Object.freeze({
  active: false,
  context: [],
  task: "",
  constraints: [],
  outputFormat: [],
  successCriteria: []
});

function normalize(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function unique(items) {
  const seen = new Set();
  return items.filter((item) => {
    const key = normalize(item).replace(/\s+/g, " ").trim();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function hasAny(text, words) {
  return words.some((word) => text.includes(word));
}

function shouldActivate(template, idea) {
  const categoryId = template?.id || "";
  if (ALWAYS_SECURE_CATEGORIES.has(categoryId)) return true;

  const normalized = normalize(idea);
  return SECURITY_KEYWORDS.some((keyword) => normalized.includes(normalize(keyword)));
}

function categoryFocus(template, idea) {
  const categoryId = template?.id || "";
  const normalized = normalize(`${categoryId} ${idea}`);
  const focus = [];

  if (CATEGORY_FOCUS[categoryId]) focus.push(...CATEGORY_FOCUS[categoryId]);
  if (hasAny(normalized, ["saas", "assinatura", "subscription", "tenant", "multi tenant", "multi-tenant"])) focus.push(...CATEGORY_FOCUS.saas);
  if (hasAny(normalized, ["site", "website", "landing", "formulario", "form", "cms"])) focus.push(...CATEGORY_FOCUS.website);
  if (hasAny(normalized, ["codigo", "code", "api", "backend", "frontend", "react", "node", "php", "python", "sql"])) focus.push(...CATEGORY_FOCUS.code);
  if (hasAny(normalized, ["ux", "interface", "dashboard", "painel", "fluxo", "mobile"])) focus.push(...CATEGORY_FOCUS.ux);
  if (hasAny(normalized, ["dados", "data", "planilha", "database", "banco", "cliente", "usuario"])) focus.push(...CATEGORY_FOCUS.data);

  return unique(focus);
}

export function getSecurityGuardrails(template, options, language) {
  const idea = options?.idea || "";
  if (!shouldActivate(template, idea)) return EMPTY_GUARDRAILS;

  const copy = COPY[language] || COPY.en;
  const focus = categoryFocus(template, idea);
  const normalized = normalize(`${template?.id || ""} ${idea}`);
  const constraints = [...copy.core];

  if (focus.some((item) => normalize(item).includes("tenant")) || hasAny(normalized, ["saas", "tenant", "assinatura", "subscription"])) {
    constraints.push(...copy.saas);
  }

  if (focus.some((item) => normalize(item).includes("form")) || hasAny(normalized, ["site", "website", "landing", "formulario", "form", "cms"])) {
    constraints.push(...copy.website);
  }

  if (focus.some((item) => normalize(item).includes("implementation")) || focus.some((item) => normalize(item).includes("implementacao")) || hasAny(normalized, ["codigo", "code", "api", "backend", "frontend", "debug", "bug", "sql"])) {
    constraints.push(...copy.code);
  }

  constraints.push(...copy.ux);

  const outputLine = options?.outputFormat === "json" ? copy.output.json : copy.output.default;
  const focusLine = focus.length
    ? language === "pt"
      ? `Foco de segurança detectado: ${focus.join(", ")}.`
      : language === "es"
        ? `Foco de seguridad detectado: ${focus.join(", ")}.`
        : `Detected security focus: ${focus.join(", ")}.`
    : "";

  return {
    active: true,
    context: [copy.context, focusLine].filter(Boolean),
    task: copy.task,
    constraints: unique(constraints),
    outputFormat: [outputLine],
    successCriteria: copy.success
  };
}
